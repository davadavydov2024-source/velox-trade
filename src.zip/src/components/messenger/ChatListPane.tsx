"use client";

import { useMemo, useState } from "react";
import { Archive, BellOff, Bell, Camera, ChevronDown, ChevronRight, Check, CheckCheck, Folder, Pin, PinOff, Search, SquarePen, X, CheckCheck as ReadIcon } from "lucide-react";
import { useToast } from "@/lib/toastContext";
import { mApi, MApiError } from "./api";
import { Avatar, MenuList, Sheet, VerifiedBadge } from "./ui";
import { StatusBadge } from "./StatusBadge";
import { SwipeRow, SwipeAction } from "./SwipeRow";
import { StoriesRow, StoryGroup } from "./Stories";
import { PersonRow, usePeopleSearch } from "./NewChatSheet";
import { useAccounts, useNow } from "./hooks";
import { MAccount, MChat, MFolder, MUserChat } from "./mtypes";
import { chatPhoto, chatTitle, formatListTime, isChatMuted, isOnline, isSavedMessages, peerUid, previewText } from "./util";

export function chatInFolder(chat: MChat, uc: MUserChat | undefined, folder: MFolder): boolean {
  if (uc?.folderIds?.includes(folder.id)) return true;
  if (folder.chatIds?.includes(chat.id)) return true;
  if (folder.includeTypes?.includes(chat.type)) return true;
  if (folder.includeTypes?.includes("unread") && (uc?.unread ?? 0) > 0) return true;
  return false;
}

export function totalUnread(chats: MChat[], ucs: Record<string, MUserChat>): number {
  const now = Date.now();
  return chats.reduce((sum, c) => {
    const uc = ucs[c.id];
    if (!uc?.unread || uc.archived || isChatMuted(uc.muted, uc.mutedUntil, now)) return sum;
    return sum + uc.unread;
  }, 0);
}

function readDraft(chatId: string): string {
  try {
    return localStorage.getItem(`mx-draft-${chatId}`) ?? "";
  } catch {
    return "";
  }
}

export function ChatListPane({
  me,
  myAccount,
  chats,
  userChats,
  folders,
  loading,
  activeId,
  storyGroups,
  storyAccounts,
  onOpenChat,
  onNewChat,
  onOpenStory,
  onCreateStory,
}: {
  me: string;
  myAccount: MAccount;
  chats: MChat[];
  userChats: Record<string, MUserChat>;
  folders: MFolder[];
  loading: boolean;
  activeId: string | null;
  storyGroups: StoryGroup[];
  storyAccounts: Record<string, MAccount | null>;
  onOpenChat: (id: string) => void;
  onNewChat: () => void;
  onOpenStory: (uid: string) => void;
  onCreateStory: () => void;
}) {
  const { toast } = useToast();
  const now = useNow(20_000);
  const peerIds = chats.filter((c) => c.type === "dm").map((c) => peerUid(c, me));
  const senderIds = chats.map((c) => c.lastMessage?.from).filter((x): x is string => !!x);
  const accounts = useAccounts(Array.from(new Set([...peerIds, ...senderIds])));

  const [folderId, setFolderId] = useState<string>("all");
  const [showArchive, setShowArchive] = useState(false);
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [menuChat, setMenuChat] = useState<MChat | null>(null);
  const [folderPick, setFolderPick] = useState<MChat[] | null>(null);
  const [muteFor, setMuteFor] = useState<MChat[] | null>(null);
  const [q, setQ] = useState("");
  const { results: peopleResults, loading: peopleLoading } = usePeopleSearch(q, q.trim().length >= 2);

  const act = async (chatIds: string[], patch: Record<string, unknown>) => {
    const res = await Promise.allSettled(chatIds.map((id) => mApi("chat-settings", { chatId: id, ...patch })));
    const bad = res.find((r) => r.status === "rejected") as PromiseRejectedResult | undefined;
    if (bad) toast("error", bad.reason instanceof MApiError ? bad.reason.message : "Не удалось применить");
  };
  const markRead = (ids: string[]) => ids.forEach((id) => mApi("read", { chatId: id }).catch(() => {}));

  const activeFolder = folders.find((f) => f.id === folderId);
  const unreadByFolder = (f: MFolder | null) =>
    chats.filter((c) => !userChats[c.id]?.archived && (!f || chatInFolder(c, userChats[c.id], f))).reduce((s, c) => s + ((userChats[c.id]?.unread ?? 0) > 0 ? 1 : 0), 0);

  const visible = useMemo(() => {
    const list = chats.filter((c) => {
      const uc = userChats[c.id];
      if (uc?.archived) return false;
      if (activeFolder && !chatInFolder(c, uc, activeFolder)) return false;
      return true;
    });
    return list.sort((a, b) => {
      const ua = userChats[a.id];
      const ub = userChats[b.id];
      if (!!ua?.pinned !== !!ub?.pinned) return ua?.pinned ? -1 : 1;
      if (ua?.pinned && ub?.pinned) return (ub.pinnedAt ?? 0) - (ua.pinnedAt ?? 0);
      return (b.lastMessage?.at ?? b.updatedAt ?? 0) - (a.lastMessage?.at ?? a.updatedAt ?? 0);
    });
  }, [chats, userChats, activeFolder]);

  const unreadTotal = chats.reduce((n, c) => n + ((userChats[c.id]?.unread ?? 0) > 0 && !userChats[c.id]?.archived ? 1 : 0), 0);
  const archived = chats.filter((c) => userChats[c.id]?.archived);
  const archivedUnread = archived.reduce((s, c) => s + (userChats[c.id]?.unread ?? 0), 0);

  const searching = q.trim().length > 0;
  const chatMatches = searching
    ? chats.filter((c) => chatTitle(c, me, accounts).toLowerCase().includes(q.trim().toLowerCase().replace(/^@/, "")))
    : [];

  const toggleSel = (id: string) =>
    setSelected((s) => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });

  const row = (c: MChat) => {
    const uc = userChats[c.id];
    const title = chatTitle(c, me, accounts);
    const saved = isSavedMessages(c, me);
    const peer = c.type === "dm" ? accounts[peerUid(c, me)] : null;
    const muted = isChatMuted(uc?.muted, uc?.mutedUntil, now);
    const unread = uc?.unread ?? 0;
    const last = c.lastMessage;
    const typing = false; // «печатает» берётся из подколлекции чата только в открытом чате (см. ChatView)
    const draft = activeId === c.id ? "" : readDraft(c.id);
    const mineLast = last?.from === me;
    const readByPeer = mineLast && last ? (c.type === "dm" ? (c.readBy?.[peerUid(c, me)] ?? 0) >= last.at : c.members.some((u) => u !== me && (c.readBy?.[u] ?? 0) >= last.at)) : false;
    const senderName = last && c.type !== "dm" && !mineLast ? accounts[last.from]?.displayName?.split(" ")[0] : mineLast && c.type !== "dm" ? "Вы" : "";
    const preview = last ? previewText(last.kind, last.text) : c.type === "channel" ? "Канал создан" : "Нет сообщений";

    const left: SwipeAction[] = [
      { label: uc?.pinned ? "Открепить" : "Закрепить", icon: uc?.pinned ? <PinOff size={21} /> : <Pin size={21} />, color: "#ff9500", onPress: () => act([c.id], { pinned: !uc?.pinned }) },
      { label: muted ? "Звук" : "Без звука", icon: muted ? <Bell size={21} /> : <BellOff size={21} />, color: "#5856d6", onPress: () => (muted ? act([c.id], { muted: false, mutedUntil: 0 }) : setMuteFor([c])) },
      { label: "Архив", icon: <Archive size={21} />, color: "#8e8e93", onPress: () => act([c.id], { archived: true }) },
    ];
    const right: SwipeAction | undefined = unread > 0 ? { label: "Прочитано", icon: <ReadIcon size={21} />, color: "#3390ec", onPress: () => markRead([c.id]) } : undefined;

    return (
      <SwipeRow
        key={c.id}
        leftActions={editMode ? [] : left}
        rightAction={editMode ? undefined : right}
        disabled={editMode}
        onClick={() => (editMode ? toggleSel(c.id) : onOpenChat(c.id))}
        onLongPress={() => { if (editMode) return; try { navigator.vibrate?.(12); } catch { /* не везде есть */ } setEditMode(true); setSelected(new Set([c.id])); }}
      >
        <div className={`mx-chat-row flex items-center gap-3 px-4 py-3 ${editMode && selected.has(c.id) ? "sel" : ""} ${!editMode && uc?.pinned && activeId !== c.id ? "pinned" : ""}`} style={activeId === c.id ? { background: "var(--mx-surface)" } : undefined}>
          <div className={`mx-av-sel ${editMode && selected.has(c.id) ? "on" : ""}`}>
            <Avatar src={chatPhoto(c, me, accounts)} name={title} seed={c.type === "dm" ? peerUid(c, me) : c.id} size={56} online={!editMode && isOnline(peer, now)}>
              {saved ? "🔖" : undefined}
            </Avatar>
            <span className="mx-av-check"><Check size={13} strokeWidth={3.5} /></span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p className="truncate text-[16.5px] flex items-center gap-1" style={{ fontWeight: unread > 0 ? 700 : 600 }}>
                {title} {peer?.verified && <VerifiedBadge size={14} />}<StatusBadge acc={peer} size={14} />
              </p>
              {muted && <BellOff size={13} className="mx-muted shrink-0" />}
              <span className="ml-auto flex items-center gap-1 shrink-0 text-[13px]" style={{ color: unread > 0 && !muted ? "var(--mx-accent)" : "var(--mx-muted)" }}>
                {mineLast && last && (readByPeer || saved ? <CheckCheck size={16} style={{ color: "var(--mx-accent)" }} /> : <Check size={16} />)}
                {last ? formatListTime(last.at, now) : ""}
              </span>
            </div>
            <div className="flex items-start gap-2 mt-0.5">
              <p className="text-[14.5px] flex-1 min-w-0" style={{ color: unread > 0 ? "var(--mx-text)" : "var(--mx-muted)", opacity: unread > 0 ? 0.85 : 1, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.3 }}>
                {typing ? (
                  <span style={{ color: "var(--mx-accent)" }}>печатает…</span>
                ) : draft ? (
                  <>
                    <span style={{ color: "var(--mx-danger)" }}>Черновик: </span>
                    {draft}
                  </>
                ) : (
                  <>
                    {senderName && <span style={{ color: "var(--mx-text)" }}>{senderName}: </span>}
                    {preview}
                  </>
                )}
              </p>
              {unread > 0 ? (
                <span className={`mx-badge shrink-0 ${muted ? "muted" : ""}`}>{unread > 99 ? "99+" : unread}</span>
              ) : uc?.pinned ? (
                <Pin size={16} className="mx-muted shrink-0 mt-0.5" style={{ transform: "rotate(45deg)" }} />
              ) : null}
            </div>
          </div>
        </div>
      </SwipeRow>
    );
  };

  const selectedIds = Array.from(selected);
  const selChats = chats.filter((c) => selected.has(c.id));
  const allPinned = selChats.length > 0 && selChats.every((c) => userChats[c.id]?.pinned);
  const allMuted = selChats.length > 0 && selChats.every((c) => isChatMuted(userChats[c.id]?.muted, userChats[c.id]?.mutedUntil, now));
  const allArchived = selChats.length > 0 && selChats.every((c) => userChats[c.id]?.archived);
  const anyUnread = selChats.some((c) => (userChats[c.id]?.unread ?? 0) > 0);
  const selectable = [...visible, ...(archiveOpen ? archived : [])];
  const allSelected = selectable.length > 0 && selectable.every((c) => selected.has(c.id));
  const selectAll = () => setSelected(allSelected ? new Set() : new Set(selectable.map((c) => c.id)));
  const exitEdit = () => {
    setEditMode(false);
    setSelected(new Set());
  };
  const bulk = async (patch: Record<string, unknown>) => {
    await act(selectedIds, patch);
    exitEdit();
  };

  return (
    <div className="flex flex-col h-full" style={{ background: "var(--mx-bg)" }}>
      {/* ---- шапка ---- */}
      <div className="mx-safe-top shrink-0">
        {editMode ? (
          <div className="mx-selbar mx-step">
            <button onClick={exitEdit} className="mx-icon-btn" aria-label="Отменить выбор"><X size={18} /></button>
            <span className="mx-selbar-count truncate">{selected.size > 0 ? `Выбрано: ${selected.size}` : "Выберите чаты"}</span>
            <button onClick={selectAll} className="mx-chip">{allSelected ? "Снять" : "Выбрать все"}</button>
          </div>
        ) : (
          <div className="px-4 pt-2 pb-2 flex items-center gap-2">
            <div className="flex-1 min-w-0">
              <h1 className="text-[30px] font-bold leading-none tracking-tight">Чаты</h1>
              {unreadTotal > 0 && <p className="text-[13px] mx-muted mt-1">{unreadTotal} непрочитанн{unreadTotal === 1 ? "ый" : "ых"}</p>}
            </div>
            <button onClick={() => setEditMode(true)} className="mx-chip">Изменить</button>
            <button onClick={onCreateStory} className="mx-icon-btn" aria-label="Новая история"><Camera size={18} /></button>
            <button onClick={onNewChat} className="mx-icon-btn" aria-label="Новое сообщение"><SquarePen size={18} /></button>
          </div>
        )}
      </div>

      <div className="mx-scroll flex-1 min-h-0" style={{ paddingBottom: editMode ? 70 : 96 }}>
        <StoriesRow groups={storyGroups} me={me} myAccount={myAccount} accounts={storyAccounts} onOpen={onOpenStory} onCreate={onCreateStory} />

        {/* поиск */}
        <div className="px-4 pb-2 pt-1">
          <div className="mx-search">
            <Search size={17} className="mx-muted" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск чатов и людей" className="bg-transparent outline-none flex-1 text-[16px]" autoCapitalize="none" />
            {q && <button onClick={() => setQ("")} className="mx-muted" aria-label="Очистить"><X size={17} /></button>}
          </div>
        </div>

        {searching ? (
          <div>
            {chatMatches.length > 0 && <p className="mx-muted text-[13px] uppercase tracking-wide px-5 py-1.5">Чаты</p>}
            {chatMatches.map(row)}
            {q.trim().length >= 2 && (
              <>
                <p className="mx-muted text-[13px] uppercase tracking-wide px-5 py-1.5">Люди</p>
                {peopleResults.filter((a) => a.uid !== me).map((a) => (
                  <PersonRow
                    key={a.uid}
                    acc={a}
                    onPress={async () => {
                      try {
                        const res = await mApi<{ chatId?: string; id?: string }>("chats", { type: "dm", memberHandles: [a.handle] });
                        const id = res.chatId ?? res.id;
                        if (id) {
                          setQ("");
                          onOpenChat(id);
                        }
                      } catch (err) {
                        toast("error", err instanceof MApiError ? err.message : "Не удалось открыть чат");
                      }
                    }}
                  />
                ))}
                {!peopleLoading && peopleResults.length === 0 && chatMatches.length === 0 && <p className="mx-muted text-center py-8">Ничего не найдено</p>}
              </>
            )}
          </div>
        ) : (
          <>
            {/* папки */}
            {folders.length > 0 && (
              <div className="pb-1">
                <div className="mx-tabs">
                  {[{ id: "all", name: "Все", emoji: "" } as MFolder, ...folders].map((f) => {
                    const on = f.id === folderId;
                    const count = f.id === "all" ? unreadByFolder(null) : unreadByFolder(f);
                    return (
                      <button key={f.id} onClick={() => setFolderId(f.id)} className={`mx-tab ${on ? "on" : ""}`}>
                        {f.emoji} {f.name}
                        {count > 0 && <span className={`mx-badge ${on ? "" : "muted"}`}>{count}</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* архив */}
            {archived.length > 0 && (
              <>
                <button onClick={() => setArchiveOpen((v) => !v)} className="w-full flex items-center gap-3 px-4 py-2.5 text-left">
                  <span className="w-14 h-14 rounded-full flex items-center justify-center text-white" style={{ background: "#8e8e93" }}><Archive size={24} /></span>
                  <span className="flex-1 font-semibold text-[16.5px]">Архив чатов</span>
                  {archivedUnread > 0 && <span className="mx-badge muted">{archivedUnread}</span>}
                  {archiveOpen ? <ChevronDown size={18} className="mx-muted" /> : <ChevronRight size={18} className="mx-muted" />}
                </button>
                {archiveOpen && archived.map(row)}
              </>
            )}

            {loading && chats.length === 0 && (
              <div>
                {Array.from({ length: 7 }).map((_, i) => (
                  <div key={i} className="flex items-center gap-3 px-4 py-3" style={{ opacity: 1 - i * 0.1 }}>
                    <div className="mx-skel rounded-full shrink-0" style={{ width: 56, height: 56 }} />
                    <div className="flex-1 space-y-2">
                      <div className="mx-skel rounded-md" style={{ width: `${40 + (i % 3) * 14}%`, height: 14 }} />
                      <div className="mx-skel rounded-md" style={{ width: `${62 + (i % 4) * 8}%`, height: 12 }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
            {visible.map(row)}
            {!loading && visible.length === 0 && archived.length === 0 && (
              <div className="text-center px-10 py-14">
                <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ background: "var(--mx-surface)", color: "var(--mx-accent)" }}><SquarePen size={26} /></div>
                <p className="text-[18px] font-semibold mb-1.5">Чатов пока нет</p>
                <p className="mx-muted text-[14px] mb-5">Найди человека по @username или создай группу.</p>
                <button className="mx-btn" style={{ width: "auto", padding: "12px 24px" }} onClick={onNewChat}>Новое сообщение</button>
              </div>
            )}
          </>
        )}
      </div>

      {editMode && (
        <div className="mx-actbar mx-glass mx-safe-bottom mx-step">
          {[
            { label: "Прочитано", icon: <ReadIcon size={21} />, off: !anyUnread, run: () => { markRead(selectedIds); exitEdit(); } },
            { label: allPinned ? "Открепить" : "Закрепить", icon: allPinned ? <PinOff size={21} /> : <Pin size={21} />, run: () => bulk({ pinned: !allPinned }) },
            { label: allMuted ? "Со звуком" : "Без звука", icon: allMuted ? <Bell size={21} /> : <BellOff size={21} />, run: () => (allMuted ? bulk({ muted: false, mutedUntil: 0 }) : setMuteFor(selChats)) },
            { label: allArchived ? "Из архива" : "В архив", icon: <Archive size={21} />, run: () => bulk({ archived: !allArchived }) },
            ...(folders.length > 0 ? [{ label: "В папку", icon: <Folder size={21} />, run: () => setFolderPick(selChats) }] : []),
          ].map((b) => (
            <button key={b.label} disabled={selected.size === 0 || ("off" in b && !!b.off)} onClick={b.run}>
              {b.icon}
              {b.label}
            </button>
          ))}
        </div>
      )}

      {/* контекстное меню чата */}
      <Sheet open={!!menuChat} onClose={() => setMenuChat(null)} title={menuChat ? chatTitle(menuChat, me, accounts) : undefined}>
        {menuChat && (() => {
          const uc = userChats[menuChat.id];
          const muted = isChatMuted(uc?.muted, uc?.mutedUntil, now);
          return (
            <MenuList
              onDone={() => setMenuChat(null)}
              items={[
                { label: uc?.pinned ? "Открепить" : "Закрепить", icon: uc?.pinned ? <PinOff size={20} /> : <Pin size={20} />, onPress: () => act([menuChat.id], { pinned: !uc?.pinned }) },
                muted
                  ? { label: "Включить звук", icon: <Bell size={20} />, onPress: () => act([menuChat.id], { muted: false, mutedUntil: 0 }) }
                  : { label: "Без звука", icon: <BellOff size={20} />, onPress: () => setMuteFor([menuChat]) },
                { label: "Прочитано", icon: <ReadIcon size={20} />, hidden: !(uc?.unread), onPress: () => markRead([menuChat.id]) },
                { label: "В папку", icon: <Folder size={20} />, hidden: folders.length === 0, onPress: () => setFolderPick([menuChat]) },
                { label: uc?.archived ? "Вернуть из архива" : "В архив", icon: <Archive size={20} />, onPress: () => act([menuChat.id], { archived: !uc?.archived }) },
              ]}
            />
          );
        })()}
      </Sheet>

      {/* выбор времени для «без звука» */}
      <Sheet open={!!muteFor} onClose={() => setMuteFor(null)} title="Отключить уведомления">
        {muteFor && (
          <MenuList
            onDone={() => { setMuteFor(null); exitEdit(); }}
            items={[
              { label: "На 1 час", ms: 3_600_000 },
              { label: "На 8 часов", ms: 8 * 3_600_000 },
              { label: "На 2 дня", ms: 2 * 86_400_000 },
              { label: "Навсегда", ms: 0 },
            ].map((o) => ({ label: o.label, icon: <BellOff size={20} />, onPress: () => act(muteFor.map((c) => c.id), { muted: true, mutedUntil: o.ms ? Date.now() + o.ms : 0 }) }))}
          />
        )}
      </Sheet>

      {/* выбор папки для одного или нескольких чатов */}
      <Sheet open={!!folderPick} onClose={() => setFolderPick(null)} title={folderPick && folderPick.length > 1 ? `Папки для чатов (${folderPick.length})` : "Папки чата"}>
        {folderPick && (
          <div className="pb-4">
            {folders.map((f) => {
              const inList = folderPick.every((c) => !!userChats[c.id]?.folderIds?.includes(f.id));
              return (
                <button
                  key={f.id}
                  onClick={async () => {
                    const list = folderPick;
                    setFolderPick(null);
                    await Promise.all(list.map((c) => {
                      const cur = userChats[c.id]?.folderIds ?? [];
                      return act([c.id], { folderIds: inList ? cur.filter((x) => x !== f.id) : Array.from(new Set([...cur, f.id])) });
                    }));
                    exitEdit();
                  }}
                  className="w-full flex items-center gap-3 px-5 py-3.5 text-left"
                >
                  <span className="text-xl w-7">{f.emoji || "📁"}</span>
                  <span className="flex-1">{f.name}</span>
                  {inList && <Check size={20} style={{ color: "var(--mx-accent)" }} />}
                </button>
              );
            })}
          </div>
        )}
      </Sheet>
    </div>
  );
}
