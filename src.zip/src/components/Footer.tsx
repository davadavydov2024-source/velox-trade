"use client";

import Link from "next/link";
import { useLanguage } from "@/lib/languageStore";

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="border-t border-border mt-16 bg-surface/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div className="col-span-2 md:col-span-1">
          <div className="flex items-center gap-2.5 mb-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/velox-mark.svg" alt="" width={30} height={30} className="w-[30px] h-[30px] rounded-[9px]" />
            <span className="font-display font-semibold">Velox<span className="text-white/40">Trade</span></span>
          </div>
          <p className="text-white/40">{t("footer_tagline")}</p>
        </div>
        <div>
          <p className="text-white/35 text-xs uppercase tracking-wider mb-3">{t("footer_shop")}</p>
          <div className="flex flex-col gap-2 text-white/70">
            <Link href="/games">{t("nav_games")}</Link>
            <Link href="/catalog">{t("nav_catalog")}</Link>
            <Link href="/catalog?new=1">{t("nav_new")}</Link>
          </div>
        </div>
        <div>
          <p className="text-white/35 text-xs uppercase tracking-wider mb-3">{t("footer_support")}</p>
          <div className="flex flex-col gap-2 text-white/70">
            <Link href="/guide">Как пользоваться сайтом</Link>
            <Link href="/chats?tab=support">{t("footer_support_center")}</Link>
            <Link href="/chats?tab=support#faq">{t("footer_faq")}</Link>
            <Link href="/reviews">Отзывы о сайте</Link>
            <Link href="/leaderboard">Топ продавцов</Link>
          </div>
        </div>
        <div>
          <p className="text-white/35 text-xs uppercase tracking-wider mb-3">Документы</p>
          <div className="flex flex-col gap-2 text-white/70">
            <Link href="/rules">Правила платформы</Link>
            <Link href="/privacy">Политика конфиденциальности</Link>
            <Link href="/terms">Пользовательское соглашение</Link>
          </div>
        </div>
        <div>
          <p className="text-white/35 text-xs uppercase tracking-wider mb-3">{t("footer_account")}</p>
          <div className="flex flex-col gap-2 text-white/70">
            <Link href="/profile">{t("footer_my_account")}</Link>
            <Link href="/profile/topup">{t("footer_topup")}</Link>
          </div>
        </div>
      </div>
      <div className="text-center text-white/30 text-xs py-4 border-t border-border">
        © {new Date().getFullYear()} Velox Trade. {t("footer_rights")}
      </div>
    </footer>
  );
}
