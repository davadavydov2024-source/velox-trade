"use client";

import { useEffect, useState } from "react";
import { doc, updateDoc } from "firebase/firestore";
import { Bell, BellOff, ShoppingBag, MessageSquare, Clock, Megaphone } from "lucide-react";
import { db, auth } from "@/lib/firebase";
import { useAuth } from "@/lib/authContext";
import { useToast } from "@/lib/toastContext";
import { isPushSupported, hasActiveSubscription, subscribeToPush, unsubscribeFromPush, describePushError, ensureCurrentDeviceSubscribed } from "@/lib/webPush";
import { PushCategories, DEFAULT_PUSH_CATEGORIES } from "@/types";

const CATEGORY_LIST: { key: keyof PushCategories; label: string; hint: string; icon: typeof ShoppingBag }[] = [
  { key: "purchases", label: "Покупки", hint: "Купили ваш товар, выигрыш на колесе фортуны", icon: ShoppingBag },
  { key: "messages", label: "Сообщения", hint: "Чат по заказу, ответы поддержки", icon: MessageSquare },
  { key: "reminders", label: "Напоминания", hint: "Забытая корзина, окончание буста товара", icon: Clock },
  { key: "news", label: "Новости", hint: "Объявления и рассылки от администрации", icon: Megaphone },
];

function Switch({ on, onClick, disabled }: { on: boolean; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`relative w-11 h-6 rounded-full transition-colors shrink-0 disabled:opacity-40 ${on ? "bg-accent" : "bg-white/15"}`}
    >
      <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${on ? "translate-x-5" : "translate-x-0"}`} />
    </button>
  );
}

export function PushToggleCard() {
  const { user, profile, refreshProfile } = useAuth();
  const { toast } = useToast();
  const [supported, setSupported] = useState(true);
  const [enabled, setEnabled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [categoryBusy, setCategoryBusy] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);
  const [testResults, setTestResults] = useState<{ id: string; label: string; current: boolean; ok: boolean; error?: string }[] | null>(null);

  const categories: PushCategories = profile?.pushCategories ?? DEFAULT_PUSH_CATEGORIES;

  useEffect(() => {
    if (!user) return;
    if (!isPushSupported()) {
      setSupported(false);
      setLoading(false);
      return;
    }
    hasActiveSubscription(user.uid)
      .then(setEnabled)
      .finally(() => setLoading(false));
  }, [user]);

  async function handleToggle() {
    if (!user) return;
    setBusy(true);
    try {
      if (enabled) {
        await unsubscribeFromPush(user.uid);
        setEnabled(false);
        toast("success", "Push-уведомления выключены");
      } else {
        await subscribeToPush(user.uid);
        setEnabled(true);
        toast("success", "Push-уведомления включены");
      }
    } catch (err: any) {
      console.error("push toggle error:", err);
      const d = describePushError(err);
      toast(d.level, d.text);
    } finally {
      setBusy(false);
    }
  }

  async function handleTest() {
    setTesting(true);
    setTestResults(null);
    try {
      // Сначала гарантируем, что ЭТО устройство записано на сервере — иначе тест мог молча уйти
      // только на другие устройства (например, на компьютер, а не на телефон, с которого нажали).
      let endpoint: string | undefined;
      try {
        endpoint = await ensureCurrentDeviceSubscribed();
      } catch (err: any) {
        const d = describePushError(err);
        toast(d.level, d.text);
        return;
      }
      const idToken = await auth.currentUser?.getIdToken();
      const res = await fetch("/api/push/test", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
        body: JSON.stringify({ endpoint }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast("error", `Сервер не смог отправить: ${data.detail || data.error}`);
        return;
      }
      setTestResults(data.results ?? []);
      const total = data.devices ?? 0;
      if (data.sent === total && total > 0) toast("success", `Отправлено на все устройства (${total}). Уведомление придёт через пару секунд`);
      else if (data.sent > 0) toast("warning", `Дошло на ${data.sent} из ${total} устройств — смотри список ниже`);
      else toast("error", "Ни одно устройство не приняло уведомление — смотри список ниже");
    } catch {
      toast("error", "Не удалось отправить тест");
    } finally {
      setTesting(false);
    }
  }

  async function handleRemoveDevice(id: string) {
    try {
      const idToken = await auth.currentUser?.getIdToken();
      const res = await fetch("/api/push/unsubscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) throw new Error();
      setTestResults((list) => (list ? list.filter((r) => r.id !== id) : list));
      toast("success", "Устройство отключено от уведомлений");
    } catch {
      toast("error", "Не удалось отключить устройство");
    }
  }

  async function handleCategoryToggle(key: keyof PushCategories) {
    if (!user) return;
    setCategoryBusy(key);
    const next = { ...categories, [key]: !categories[key] };
    try {
      await updateDoc(doc(db, "users", user.uid), { pushCategories: next });
      await refreshProfile();
    } catch {
      toast("error", "Не удалось сохранить настройку");
    } finally {
      setCategoryBusy(null);
    }
  }

  if (!supported) return null;

  return (
    <div className="card p-5 space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {enabled ? <Bell size={18} className="text-accent" /> : <BellOff size={18} className="text-white/40" />}
          <div>
            <p className="font-medium">Push-уведомления в браузере</p>
            <p className="text-sm text-white/40">Новые сообщения и заказы — даже если сайт не открыт</p>
          </div>
        </div>
        <Switch on={enabled} onClick={handleToggle} disabled={loading || busy} />
      </div>

      {enabled && (
        <button type="button" onClick={handleTest} disabled={testing} className="btn-secondary w-full py-2 text-sm disabled:opacity-50">
          {testing ? "Отправляем..." : "Отправить тестовое уведомление"}
        </button>
      )}

      {enabled && testResults && (
        <div className="rounded-btn bg-white/[0.03] border border-white/5 divide-y divide-white/5 text-sm">
          {testResults.length === 0 ? (
            <p className="p-3 text-white/50">Нет ни одного зарегистрированного устройства.</p>
          ) : (
            testResults.map((r, i) => (
              <div key={i} className="p-3 flex items-start gap-2">
                <span className={r.ok ? "text-green-400" : "text-red-400"}>{r.ok ? "✓" : "✕"}</span>
                <div className="min-w-0">
                  <p>
                    {r.label}
                    {r.current && <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded-full bg-accent/15 text-accent">это устройство</span>}
                  </p>
                  {r.error && <p className="text-xs text-red-400/80 break-words">{r.error}</p>}
                </div>
                {!r.current && (
                  <button type="button" onClick={() => handleRemoveDevice(r.id)} className="ml-auto shrink-0 text-xs text-white/40 hover:text-red-400 transition-colors">
                    Отключить
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {enabled && (
        <div className="pt-3 border-t border-white/10 space-y-3">
          <p className="text-xs text-white/40">Что присылать</p>
          {CATEGORY_LIST.map(({ key, label, hint, icon: Icon }) => (
            <div key={key} className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <Icon size={15} className="text-white/40 shrink-0" />
                <div>
                  <p className="text-sm">{label}</p>
                  <p className="text-xs text-white/35">{hint}</p>
                </div>
              </div>
              <Switch on={categories[key] !== false} onClick={() => handleCategoryToggle(key)} disabled={categoryBusy === key} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
