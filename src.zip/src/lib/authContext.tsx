"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithCustomToken,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut as fbSignOut,
  sendEmailVerification,
  sendPasswordResetEmail,
  updateProfile,
  User,
} from "firebase/auth";
import { auth, googleProvider } from "./firebase";
import { ensureUserProfile, getUserProfile, syncEmailVerified } from "./users";
import { UserProfile } from "@/types";
import { getActiveSlotId, upsertSavedAccount } from "./accountSlots";

/** Бан считается действующим, если banned=true и (until не задан/"forever", либо ещё не истёк). */
export function isEffectivelyBanned(profile: UserProfile | null): boolean {
  if (!profile?.banned) return false;
  if (!profile.banUntil || profile.banUntil === "forever") return true;
  return profile.banUntil > Date.now();
}

interface AuthContextValue {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  refreshProfile: () => Promise<UserProfile | null>;
  login: (email: string, password: string) => Promise<void>;
  loginWithCustomToken: (token: string) => Promise<void>;
  register: (email: string, password: string, name: string, language?: "ru" | "en" | "zh") => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  async function refreshProfile() {
    if (!auth.currentUser) {
      setProfile(null);
      return null;
    }
    try {
      await auth.currentUser.reload();
      await syncEmailVerified(auth.currentUser.uid, auth.currentUser.emailVerified);
    } catch {
      // Не критично — просто покажем то, что уже знаем
    }
    const p = await getUserProfile(auth.currentUser.uid);
    setProfile(p);
    return p;
  }

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        try {
          await u.reload();
        } catch {
          // офлайн или сеть недоступна — просто продолжаем с тем, что уже знаем
        }
        const p = await ensureUserProfile(u.uid, u.email ?? "", u.displayName ?? u.email ?? "Игрок", u.photoURL ?? undefined);
        if (u.emailVerified && !p.emailVerified) {
          await syncEmailVerified(u.uid, true);
          p.emailVerified = true;
        }
        setProfile(p);
        // Держим список аккаунтов в переключателе актуальным — чем бы человек ни вошёл
        // (обычным логином на "primary" или переключением на добавленный аккаунт).
        upsertSavedAccount({
          slotId: getActiveSlotId(),
          uid: u.uid,
          email: u.email ?? "",
          displayName: u.displayName ?? u.email ?? "Игрок",
          photoURL: u.photoURL ?? undefined,
        });
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  async function login(email: string, password: string) {
    await signInWithEmailAndPassword(auth, email, password);
  }

  async function loginWithCustomToken(token: string) {
    await signInWithCustomToken(auth, token);
  }

  async function register(email: string, password: string, name: string, language?: "ru" | "en" | "zh") {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName: name });
    await sendEmailVerification(cred.user);
    await ensureUserProfile(cred.user.uid, email, name, undefined, language);
  }

  async function loginWithGoogle() {
    await signInWithPopup(auth, googleProvider);
  }

  async function logout() {
    await fbSignOut(auth);
  }

  async function resetPassword(email: string) {
    // Firebase сам генерирует ссылку и шлёт письмо со своего сервера — не нужен ни серверный
    // роут с Admin SDK, ни сторонний EmailJS. Шаблон письма можно настроить в
    // Firebase Console → Authentication → Templates → Password reset.
    await sendPasswordResetEmail(auth, email);
  }

  return (
    <AuthContext.Provider
      value={{ user, profile, loading, refreshProfile, login, loginWithCustomToken, register, loginWithGoogle, logout, resetPassword }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth должен использоваться внутри <AuthProvider>");
  return ctx;
}
