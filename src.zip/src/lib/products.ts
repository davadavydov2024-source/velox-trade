import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit as fsLimit,
  addDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "./firebase";
import { auth } from "./firebase";
import { Game, Product } from "@/types";
import { getActiveWheelProductIds } from "./wheelPrizes";

const gamesCol = collection(db, "games");
const productsCol = collection(db, "products");

export async function getGames(): Promise<Game[]> {
  const snap = await getDocs(gamesCol);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Game);
}

export async function getGameBySlug(slug: string): Promise<Game | null> {
  const snap = await getDocs(query(gamesCol, where("slug", "==", slug), fsLimit(1)));
  if (snap.empty) return null;
  const d = snap.docs[0];
  return { id: d.id, ...d.data() } as Game;
}

export async function getProducts(opts?: {
  gameId?: string;
  sellerId?: string;
  rarity?: string;
  isNew?: boolean;
  sort?: "price_asc" | "price_desc" | "newest";
  /** По умолчанию false — товары, "запертые" под колесо фортуны (см. getActiveWheelProductIds),
   * не исключаются. Ставь true на всех покупательских страницах (каталог, главная, товар,
   * профиль продавца), чтобы такие товары нельзя было купить в обход колеса. В админке и на
   * странице самого колеса оставляй false — там их обязательно нужно видеть. */
  excludeWheelLocked?: boolean;
}): Promise<Product[]> {
  const clauses = [];
  if (opts?.gameId) clauses.push(where("gameId", "==", opts.gameId));
  if (opts?.sellerId) clauses.push(where("sellerId", "==", opts.sellerId));
  if (opts?.rarity) clauses.push(where("rarity", "==", opts.rarity));
  if (opts?.isNew) clauses.push(where("isNew", "==", true));

  // Сортируем на клиенте, а не через Firestore orderBy: комбинация where + orderBy на разных
  // полях требует отдельного составного индекса на КАЖДОЕ сочетание фильтров, что означало бы
  // создание нескольких индексов вручную в консоли Firebase. Товаров в каталоге не миллионы,
  // так что сортировка в JS обходится дёшево и работает сразу без лишней настройки.
  const snap = await getDocs(query(productsCol, ...clauses));
  let products = snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Product);

  if (opts?.excludeWheelLocked) {
    const lockedIds = await getActiveWheelProductIds();
    if (lockedIds.size > 0) products = products.filter((p) => !lockedIds.has(p.id));
  }

  if (opts?.sort === "price_asc") products.sort((a, b) => a.price - b.price);
  else if (opts?.sort === "price_desc") products.sort((a, b) => b.price - a.price);
  else products.sort((a, b) => b.createdAt - a.createdAt);

  return products;
}

/**
 * Как getProductById, но возвращает null и для товаров, "запертых" под колесо фортуны — чтобы их
 * нельзя было открыть/купить напрямую по ссылке в обход колеса. Используй на покупательской
 * странице товара; для чата заказа и других служебных мест оставляй обычный getProductById.
 */
export async function getPurchasableProductById(id: string): Promise<Product | null> {
  const [product, lockedIds] = await Promise.all([getProductById(id), getActiveWheelProductIds()]);
  if (!product || lockedIds.has(product.id)) return null;
  return product;
}

export async function getProductById(id: string): Promise<Product | null> {
  const ref = doc(db, "products", id);
  const snap = await getDoc(ref);
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Product;
}

export async function createProduct(data: Omit<Product, "id" | "createdAt">) {
  const ref = await addDoc(productsCol, { ...data, createdAt: Date.now() });
  // Уведомляем всех, у кого привязан Telegram, о новом товаре — не критично для основного
  // действия, поэтому не ждём и игнорируем ошибки (например, если это не админ, а обычный
  // клиент без прав — сервер сам вернёт 403 и просто ничего не разошлёт).
  auth.currentUser?.getIdToken().then((idToken) => {
    fetch("/api/notify/new-product", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
      body: JSON.stringify({ name: data.name, price: data.price }),
    }).catch(() => {});
  });
  return ref;
}

export async function updateProduct(id: string, data: Partial<Product>) {
  return updateDoc(doc(db, "products", id), data);
}

export async function deleteProduct(id: string) {
  return deleteDoc(doc(db, "products", id));
}

/** Покупка продвижения товара продавцом за баланс — идёт через сервер (см. api/products/boost). */
export async function boostProduct(productId: string, tier: "game" | "home"): Promise<{ boostTier: string; boostUntil: number }> {
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("Нужно войти в аккаунт");
  const idToken = await currentUser.getIdToken();
  const res = await fetch("/api/products/boost", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
    body: JSON.stringify({ productId, tier }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Не удалось оформить продвижение");
  return data;
}

export async function createGame(data: Omit<Game, "id">) {
  return addDoc(gamesCol, data);
}

export async function updateGame(id: string, data: Partial<Game>) {
  return updateDoc(doc(db, "games", id), data);
}

export async function deleteGame(id: string) {
  return deleteDoc(doc(db, "games", id));
}

export { serverTimestamp };
