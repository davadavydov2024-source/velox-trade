import { doc, getDoc, setDoc, updateDoc, arrayUnion, collection, query, where, getDocs, onSnapshot, QuerySnapshot, DocumentData } from "firebase/firestore";
import { db } from "./firebase";
import { OrderChat, OrderChatMessage } from "@/types";
import { notifyTelegram, notifyTelegramChat, notifyEmail } from "./telegramNotify";
import { previewText, escapeHtml } from "./chatFormat";
import { notifyPush } from "./webPushNotify";

function chatRef(orderId: string) {
  return doc(db, "orderChats", orderId);
}

export async function getOrderChat(orderId: string): Promise<OrderChat | null> {
  try {
    const snap = await getDoc(chatRef(orderId));
    return snap.exists() ? (snap.data() as OrderChat) : null;
  } catch {
    // Чат создаётся лениво при первом сообщении — до этого документа физически нет, и без
    // соответствующего условия в правилах Firestore это раньше падало с permission-denied
    // (см. фикс в firestore.rules). Ловим здесь тоже — работает сразу, не дожидаясь передеплоя
    // правил, и на всякий случай прикрывает любые другие похожие ситуации.
    return null;
  }
}

/** Живая подписка на один чат по заказу — сообщения появляются сами, без перезагрузки страницы. */
export function subscribeOrderChat(orderId: string, cb: (chat: OrderChat | null) => void) {
  return onSnapshot(chatRef(orderId), (snap) => cb(snap.exists() ? (snap.data() as OrderChat) : null), () => cb(null));
}

/** Живая подписка на все чаты пользователя (как покупателя и как продавца) — для бейджей
 * "новое сообщение" и всплывающих уведомлений на сайте, пока человек на сайте. */
export function subscribeUserOrderChats(uid: string, cb: (chats: OrderChat[]) => void) {
  const col = collection(db, "orderChats");
  const state = new Map<string, OrderChat>();
  const emit = () => cb(Array.from(state.values()).sort((a, b) => b.updatedAt - a.updatedAt));

  const applySnapshot = (snap: QuerySnapshot<DocumentData>) => {
    snap.docChanges().forEach((change) => {
      if (change.type === "removed") state.delete(change.doc.id);
      else state.set(change.doc.id, change.doc.data() as OrderChat);
    });
    emit();
  };

  const unsub1 = onSnapshot(query(col, where("buyerId", "==", uid)), applySnapshot);
  const unsub2 = onSnapshot(query(col, where("sellerId", "==", uid)), applySnapshot);
  return () => {
    unsub1();
    unsub2();
  };
}

/** Все чаты по сделкам, где пользователь — покупатель или продавец, для раздела «Чаты». */
export async function getUserOrderChats(uid: string): Promise<OrderChat[]> {
  const col = collection(db, "orderChats");
  const [asBuyer, asSeller] = await Promise.all([
    getDocs(query(col, where("buyerId", "==", uid))),
    getDocs(query(col, where("sellerId", "==", uid))),
  ]);
  const map = new Map<string, OrderChat>();
  asBuyer.docs.forEach((d) => map.set(d.id, d.data() as OrderChat));
  asSeller.docs.forEach((d) => map.set(d.id, d.data() as OrderChat));
  return Array.from(map.values()).sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function sendOrderChatMessage(
  orderId: string,
  buyerId: string,
  sellerId: string,
  from: OrderChatMessage["from"],
  text: string,
  imageUrl?: string
) {
  const ref = chatRef(orderId);
  const snap = await getDoc(ref);
  const message: OrderChatMessage = { from, text, createdAt: Date.now(), ...(imageUrl ? { imageUrl } : {}) };

  if (!snap.exists()) {
    await setDoc(ref, { orderId, buyerId, sellerId, messages: arrayUnion(message), updatedAt: Date.now() }, { merge: true });
  } else {
    await updateDoc(ref, { messages: arrayUnion(message), updatedAt: Date.now() });
  }

  // Уведомляем в Telegram и push-уведомлением в браузере того, кому адресовано сообщение —
  // только для настоящих реплик участников, автоматические системные записи (подтверждение
  // получения, открытие спора и т.п.) уведомлений не шлют, чтобы не спамить.
  // Превью без разметки и со спрятанным скрытым текстом (push, email) — "||секрет||" не должен уходить открытым.
  const plain = previewText(text, 200);
  const preview = imageUrl ? (text.trim() ? `📷 ${plain}` : "📷 Фото") : plain;
  // В Telegram форматирование сохраняется, а скрытое приходит спойлером.
  const tg = (uid: string, head: string) => {
    if (!text.trim()) notifyTelegram(uid, `${head}\n${preview}`);
    else notifyTelegramChat(uid, imageUrl ? `${head}\n📷` : head, text);
  };
  const emailBody = (who: string) =>
    `<div style="font-family:sans-serif;font-size:15px;color:#111;line-height:1.6;">
      <p>${who} написал(а) в чате по твоему заказу:</p>
      <p style="background:#f5f5f5;border-radius:8px;padding:12px;margin:12px 0;">${escapeHtml(preview)}</p>
      <p style="color:#666;font-size:13px;">Ответить можно на сайте, в разделе «Чаты».</p>
    </div>`;

  if (from === "buyer") {
    tg(sellerId, "💬 Новое сообщение по заказу от покупателя:");
    notifyPush(sellerId, "Новое сообщение по заказу", preview, "/chats");
    notifyEmail(sellerId, "Новое сообщение по заказу", emailBody("Покупатель"));
  } else if (from === "seller") {
    tg(buyerId, "💬 Новое сообщение по заказу от продавца:");
    notifyPush(buyerId, "Новое сообщение по заказу", preview, "/chats");
    notifyEmail(buyerId, "Новое сообщение по заказу", emailBody("Продавец"));
  } else if (from === "admin") {
    tg(buyerId, "💬 Администратор написал в чате по заказу:");
    tg(sellerId, "💬 Администратор написал в чате по заказу:");
    notifyPush(buyerId, "Администратор написал в чате", preview, "/chats");
    notifyEmail(buyerId, "Администратор написал в чате по заказу", emailBody("Администратор"));
    notifyEmail(sellerId, "Администратор написал в чате по заказу", emailBody("Администратор"));
    notifyPush(sellerId, "Администратор написал в чате", preview, "/chats");
  }
}
