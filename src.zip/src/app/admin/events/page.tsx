"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, Power, Snowflake, Sun, Sparkles, Cake, Rocket, RefreshCw } from "lucide-react";
import { getAllEvents, createEvent, updateEvent, deleteEvent } from "@/lib/events";
import { SiteEvent, EventTheme } from "@/types";
import { useToast } from "@/lib/toastContext";

type FormState = {
  name: string;
  bonusRub: number;
  theme: EventTheme;
  active: boolean;
};

const EMPTY_FORM: FormState = { name: "", bonusRub: 15, theme: "none", active: false };

const THEME_ICON: Record<EventTheme, typeof Snowflake> = {
  winter: Snowflake,
  summer: Sun,
  birthday: Cake,
  milestone: Sparkles,
  update: Rocket,
  weekly: RefreshCw,
  none: Sparkles,
};

const THEME_LABEL: Record<EventTheme, string> = {
  winter: "Зимнее оформление (снег)",
  summer: "Летнее оформление (солнце)",
  birthday: "День рождения (шарики, конфетти)",
  milestone: "Веха / круглая дата (салют, искры)",
  update: "Обновление сайта (ракеты вверх)",
  weekly: "Еженедельный ивент (звёзды)",
  none: "Без оформления",
};

// Готовые заготовки — один клик заполняет форму, дальше можно поправить любое поле.
const PRESETS: { label: string; name: string; bonusRub: number; theme: EventTheme }[] = [
  { label: "Зима", name: "Зима", bonusRub: 15, theme: "winter" },
  { label: "Лето", name: "Лето", bonusRub: 18, theme: "summer" },
  { label: "День 67", name: "День 67", bonusRub: 20, theme: "milestone" },
  { label: "День 62", name: "День 62", bonusRub: 20, theme: "milestone" },
  { label: "ДР админа", name: "День рождения администратора 🎂", bonusRub: 25, theme: "birthday" },
  { label: "Еженедельный ивент", name: "Еженедельный ивент", bonusRub: 10, theme: "weekly" },
  { label: "Ивент обновлений", name: "Новое обновление сайта!", bonusRub: 12, theme: "update" },
];

export default function AdminEventsPage() {
  const { toast } = useToast();
  const [events, setEvents] = useState<SiteEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);

  useEffect(() => {
    refresh();
  }, []);

  async function refresh() {
    setLoading(true);
    setEvents(await getAllEvents());
    setLoading(false);
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) {
      toast("warning", "Укажи название ивента");
      return;
    }
    try {
      await createEvent(form);
      toast("success", `Ивент «${form.name}» создан`);
      setForm(EMPTY_FORM);
      setShowForm(false);
      await refresh();
    } catch {
      toast("error", "Не удалось создать ивент");
    }
  }

  async function toggleActive(ev: SiteEvent) {
    await updateEvent(ev.id, { active: !ev.active });
    await refresh();
  }

  async function handleDelete(id: string) {
    if (!confirm("Удалить этот ивент?")) return;
    await deleteEvent(id);
    await refresh();
  }

  function applyPreset(preset: (typeof PRESETS)[number]) {
    setForm({ name: preset.name, bonusRub: preset.bonusRub, theme: preset.theme, active: false });
    setShowForm(true);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold mb-1">Ивенты</h1>
          <p className="text-sm text-white/40">
            Сезонные и разовые события: тематическое оформление сайта + бонус на баланс, который пользователь
            получает один раз за ивент. Обычно активен один ивент за раз — включай/выключай кнопкой.
          </p>
        </div>
        <button onClick={() => setShowForm((v) => !v)} className="btn-primary px-4 py-2.5 flex items-center gap-2">
          <Plus size={16} /> Новый ивент
        </button>
      </div>

      <div className="card p-5 flex flex-wrap gap-2">
        <p className="text-sm text-white/40 w-full mb-1">Готовые заготовки — жми, дальше можно поправить в форме:</p>
        {PRESETS.map((preset) => {
          const Icon = THEME_ICON[preset.theme];
          return (
            <button
              key={preset.label}
              onClick={() => applyPreset(preset)}
              className="btn-secondary px-3.5 py-2 text-sm flex items-center gap-2"
            >
              <Icon size={14} /> {preset.label}
            </button>
          );
        })}
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="card p-5 space-y-3">
          <div className="grid sm:grid-cols-2 gap-3">
            <input
            autoComplete="off"
              placeholder="Название (например Зима)"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="input-field py-2.5"
            />
            <input
            autoComplete="off"
              type="number"
              min={0}
              placeholder="Бонус на баланс, ₽"
              value={form.bonusRub}
              onChange={(e) => setForm({ ...form, bonusRub: Number(e.target.value) })}
              className="input-field py-2.5"
            />
          </div>
          <select
            value={form.theme}
            onChange={(e) => setForm({ ...form, theme: e.target.value as EventTheme })}
            className="input-field py-2.5 w-full"
          >
            {(Object.keys(THEME_LABEL) as EventTheme[]).map((theme) => (
              <option key={theme} value={theme}>
                {THEME_LABEL[theme]}
              </option>
            ))}
          </select>
          <label className="flex items-center gap-2 text-sm text-white/60">
            <input
            autoComplete="off" type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} />
            Сделать активным сразу
          </label>
          <div className="flex gap-2">
            <button className="btn-primary px-5 py-2.5 text-sm">Создать</button>
            <button type="button" onClick={() => setShowForm(false)} className="btn-secondary px-5 py-2.5 text-sm">
              Отмена
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <div className="card p-10 text-center text-white/40">Загрузка...</div>
      ) : events.length === 0 ? (
        <div className="card p-10 text-center text-white/40">Ивентов пока нет — выбери заготовку или создай свой выше.</div>
      ) : (
        <div className="space-y-3">
          {events.map((ev) => {
            const Icon = THEME_ICON[ev.theme] ?? Sparkles;
            return (
              <div key={ev.id} className={`card p-4 flex items-center justify-between gap-4 ${ev.active ? "border-accent/50" : ""}`}>
                <div className="flex items-center gap-3">
                  <Icon size={20} className={ev.active ? "text-accent" : "text-white/30"} />
                  <div>
                    <p className="font-medium">{ev.name}</p>
                    <p className="text-xs text-white/40">
                      +{ev.bonusRub} ₽ на баланс · {THEME_LABEL[ev.theme] ?? "Без оформления"} · {ev.active ? "Активен" : "Выключен"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => toggleActive(ev)}
                    className={`px-3 py-2 rounded-btn text-sm flex items-center gap-1.5 ${ev.active ? "bg-accent text-black" : "btn-secondary"}`}
                  >
                    <Power size={14} /> {ev.active ? "Выключить" : "Включить"}
                  </button>
                  <button onClick={() => handleDelete(ev.id)} className="p-2 rounded-btn hover:bg-white/5 text-red-400">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
