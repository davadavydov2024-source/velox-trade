"use client";

import { useEffect, useRef, useState, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Mail, Lock, User, ExternalLink, MessageCircle, CheckCircle2, Sparkles, ChevronLeft, CalendarDays, Eye, EyeOff, Check } from "lucide-react";
import { useAuth } from "@/lib/authContext";
import { auth } from "@/lib/firebase";
import { useToast } from "@/lib/toastContext";
import { getFeatureFlags } from "@/lib/featureFlags";
import { DEFAULT_FEATURE_FLAGS, FeatureFlags } from "@/types";
import { createTelegramRegisterRequest } from "@/lib/telegramRegister";
import { useLanguage, useLanguageStore } from "@/lib/languageStore";
import { LANGUAGES } from "@/lib/i18n";
import { useMascot } from "@/lib/mascotContext";
import { AuthBackground } from "@/components/AuthBackground";
import { TelegramLoginWidget } from "@/components/TelegramLoginWidget";
import { isUsernameAvailable, saveMyUsername, usernameFormatError } from "@/lib/usernames";

const TELEGRAM_BOT = process.env.NEXT_PUBLIC_TELEGRAM_BOT || "veloxtrade_robot";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function translateAuthError(code?: string) {
  switch (code) {
    case "auth/email-already-in-use":
      return "Этот email уже зарегистрирован";
    case "auth/invalid-email":
      return "Некорректный email";
    case "auth/weak-password":
      return "Слишком простой пароль";
    default:
      return "Ошибка регистрации. Попробуйте снова";
  }
}

// Шаги мастера регистрации — каждый рисуется как отдельная "страница" внутри карточки, со
// слайд-анимацией между ними (см. .auth-step-forward/.auth-step-back в globals.css).
// 0 — язык + способ регистрации; 1..4 — только для способа "пароль" (имя → email → возраст →
// пароль); путь "телеграм" со своего step 1 показывает одну форму (имя+email+возраст) и дальше сам
// управляет внутренними состояниями (ссылка на бота / ожидание / подтверждено).
// Шаги мастера регистрации — каждый рисуется как отдельная "страница" внутри карточки, со
// слайд-анимацией между ними (см. .auth-step-forward/.auth-step-back в globals.css).
// 0 — язык + способ регистрации; 1..4 — только для способа "пароль" (имя → email → возраст →
// пароль); путь "телеграм" со своего step 1 показывает одну форму (имя+email+возраст) и дальше сам
// управляет внутренними состояниями (ссылка на бота / ожидание / подтверждено).
type Step = 0 | 1 | 2;
const MIN_AGE = 6;
const MAX_AGE = 120;

function passwordStrength(pw: string): { score: number; label: string; color: string } {
  if (!pw) return { score: 0, label: "", color: "transparent" };
  let score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 10) score++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) score++;
  const labels = ["Слишком короткий", "Слабый", "Средний", "Хороший", "Надёжный"];
  const colors = ["#f87171", "#f87171", "#fbbf24", "#a3e635", "#4ade80"];
  if (pw.length < 6) return { score: 0, label: labels[0], color: colors[0] };
  return { score, label: labels[score], color: colors[score] };
}

const STEP_LABELS = ["Старт", "Данные", "Telegram"];

function RegisterInner() {
  const { register, refreshProfile } = useAuth();
  const { toast } = useToast();
  const { celebrate } = useMascot();
  const router = useRouter();
  const searchParams = useSearchParams();
  const refCode = searchParams.get("ref");
  const { t } = useLanguage();
  const language = useLanguageStore((s) => s.language);
  const setLanguage = useLanguageStore((s) => s.setLanguage);

  const [flags, setFlags] = useState<FeatureFlags>(DEFAULT_FEATURE_FLAGS);
  const [flagsLoaded, setFlagsLoaded] = useState(false);
  const [mode, setMode] = useState<"password" | "telegram">("password");
  const [step, setStep] = useState<Step>(0);
  const [dir, setDir] = useState<1 | -1>(1);

  useEffect(() => {
    getFeatureFlags().then((f) => {
      setFlags(f);
      setFlagsLoaded(true);
      if (!f.telegramRegisterEnabled) setMode("password");
    });
  }, []);

  function goNext() {
    setDir(1);
    setStep((s) => Math.min(2, s + 1) as Step);
  }
  function goBack() {
    setDir(-1);
    setStep((s) => Math.max(0, s - 1) as Step);
  }

  // --- регистрация по паролю ---
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [tgUsername, setTgUsername] = useState("");
  const [email, setEmail] = useState("");
  const [age, setAge] = useState("");
  const [password, setPassword] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [emailTouched, setEmailTouched] = useState(false);
  const [loading, setLoading] = useState(false);

  // --- обязательное подтверждение через Telegram-бота (шаг 2 пути "пароль") ---
  const [tgvToken, setTgvToken] = useState<string | null>(null);
  const [tgvUrl, setTgvUrl] = useState<string | null>(null);
  const [tgvSent, setTgvSent] = useState(false);
  const [tgvCode, setTgvCode] = useState("");

  // --- регистрация через Telegram ---
  const [tgName, setTgName] = useState("");
  const [tgEmail, setTgEmail] = useState("");
  const [tgAge, setTgAge] = useState("");
  const [tgLinkUrl, setTgLinkUrl] = useState<string | null>(null);
  const [tgCode, setTgCode] = useState<string | null>(null);
  const [tgCreating, setTgCreating] = useState(false);
  const [tgConfirmed, setTgConfirmed] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  // Ждём, пока человек откроет бота и нажмёт Start — как только бот отправил код в Telegram,
  // показываем поле для его ввода.
  useEffect(() => {
    if (step !== 2 || !tgvToken || tgvSent) return;
    const id = setInterval(async () => {
      try {
        const res = await fetch(`/api/auth/tg-verify/status?token=${tgvToken}`);
        const data = await res.json();
        if (data.sent) setTgvSent(true);
      } catch {
        // сеть моргнула — попробуем на следующем тике
      }
    }, 2500);
    return () => clearInterval(id);
  }, [step, tgvToken, tgvSent]);

  // Шаг 1 -> 2: все данные введены одной формой — проверяем и запускаем обязательное
  // подтверждение через Telegram-бота.
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      toast("warning", "Введи имя");
      return;
    }
    const usernameErr = usernameFormatError(username);
    if (usernameErr) {
      toast("warning", usernameErr);
      return;
    }
    if (!EMAIL_RE.test(email.trim())) {
      toast("warning", "Введи корректный email");
      return;
    }
    const ageValue = Number(age);
    if (!Number.isInteger(ageValue) || ageValue < MIN_AGE || ageValue > MAX_AGE) {
      toast("warning", `Укажи реальный возраст (от ${MIN_AGE} до ${MAX_AGE})`);
      return;
    }
    if (password.length < 6) {
      toast("warning", "Пароль должен быть не короче 6 символов");
      return;
    }
    setLoading(true);
    try {
      if (!(await isUsernameAvailable(username))) {
        toast("warning", "Этот юзернейм уже занят");
        return;
      }
      const res = await fetch("/api/auth/tg-verify/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast("error", data.error || "Не удалось начать подтверждение");
        return;
      }
      setTgvToken(data.token);
      setTgvUrl(data.botUrl);
      setTgvSent(false);
      setTgvCode("");
      goNext();
    } catch {
      toast("error", "Не удалось начать подтверждение");
    } finally {
      setLoading(false);
    }
  }

  // Шаг 5: код из Telegram введён — проверяем, создаём аккаунт и привязываем этот же Telegram.
  async function handleConfirmTelegramCode(e: React.FormEvent) {
    e.preventDefault();
    if (!tgvToken) return;
    setLoading(true);
    try {
      const res = await fetch("/api/auth/tg-verify/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: tgvToken, code: tgvCode.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast("error", data.error || "Не удалось проверить код");
        return;
      }

      // Пока идёт регистрация, окно «придумай юзернейм» (UsernameGate) не показываем.
      try { sessionStorage.setItem("registering-username", "1"); } catch {}
      await register(email, password, name, language, Number(age));
      try {
        if (auth.currentUser) {
          await saveMyUsername(auth.currentUser.uid, username);
          await refreshProfile();
        }
      } catch {
        // Успели занять между проверкой и созданием аккаунта — сайт попросит выбрать другой.
        toast("warning", "Юзернейм успели занять — выбери другой на следующем экране");
      } finally {
        try { sessionStorage.removeItem("registering-username"); } catch {}
      }

      try {
        const idToken = await auth.currentUser?.getIdToken();
        if (idToken) {
          const fin = await fetch("/api/auth/tg-verify/finalize", {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
            body: JSON.stringify({ token: tgvToken }),
          });
          if (!fin.ok) toast("warning", "Аккаунт создан, но Telegram привязать не удалось — сделай это в профиле → «Безопасность»");
        }
      } catch {
        toast("warning", "Аккаунт создан, но Telegram привязать не удалось — сделай это в профиле → «Безопасность»");
      }

      if (refCode) {
        try {
          const idToken = await auth.currentUser?.getIdToken();
          if (idToken) {
            await fetch("/api/auth/apply-referral", {
              method: "POST",
              headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
              body: JSON.stringify({ code: refCode }),
            });
          }
        } catch {
          // Реферальный бонус не критичен для регистрации — молча игнорируем ошибку.
        }
      }
      toast("success", "Аккаунт создан, Telegram подключён!");
      celebrate("register");
      router.push("/profile");
    } catch (err: any) {
      try { sessionStorage.removeItem("registering-username"); } catch {}
      toast("error", translateAuthError(err?.code));
    } finally {
      setLoading(false);
    }
  }

  async function handleStartTelegramRegister(e: React.FormEvent) {
    e.preventDefault();
    const tgUsernameErr = usernameFormatError(tgUsername);
    if (tgUsernameErr) {
      toast("warning", tgUsernameErr);
      return;
    }
    const ageValue = Number(tgAge);
    if (!Number.isInteger(ageValue) || ageValue < MIN_AGE || ageValue > MAX_AGE) {
      toast("warning", `Укажи реальный возраст (от ${MIN_AGE} до ${MAX_AGE})`);
      return;
    }
    setTgCreating(true);
    try {
      if (!(await isUsernameAvailable(tgUsername))) {
        toast("warning", "Этот юзернейм уже занят");
        return;
      }
      const code = await createTelegramRegisterRequest(tgEmail, tgName, ageValue, tgUsername);
      setTgCode(code);
      setTgLinkUrl(`https://t.me/${TELEGRAM_BOT}?start=${code}`);

      pollRef.current = setInterval(async () => {
        try {
          const res = await fetch(`/api/telegram/register-status?code=${code}`);
          const data = await res.json();
          if (data.done) {
            setTgConfirmed(true);
            if (pollRef.current) clearInterval(pollRef.current);
          }
        } catch {
          // сеть моргнула — просто попробуем на следующем тике
        }
      }, 3000);
    } catch (err: any) {
      if (err?.code === "permission-denied") {
        toast("error", "Нет доступа к базе данных. Проверь, что правила Firestore опубликованы.");
      } else {
        toast("error", "Не удалось начать регистрацию");
      }
    } finally {
      setTgCreating(false);
    }
  }

  if (!flagsLoaded) {
    return (
      <div className="relative min-h-[calc(100vh-64px)] flex items-center justify-center px-4">
        <AuthBackground />
        <p className="text-white/40">Загрузка...</p>
      </div>
    );
  }

  if (!flags.registrationEnabled) {
    return (
      <div className="relative min-h-[calc(100vh-64px)] flex items-center justify-center px-4 py-16">
        <AuthBackground />
        <div className="card auth-card-rise p-8 text-center max-w-md w-full">
          <h1 className="text-xl font-bold mb-2">Регистрация временно закрыта</h1>
          <p className="text-white/40 text-sm">
            Администратор временно отключил регистрацию новых аккаунтов. Попробуй зайти позже.
          </p>
          <Link href="/auth/login" className="text-accent hover:underline text-sm mt-4 inline-block">
            ← Ко входу
          </Link>
        </div>
      </div>
    );
  }

  const pwStrength = passwordStrength(password);
  const usesSteps = mode === "password" && flags.registrationEnabled;
  const totalSteps = 3; // 0 старт, 1 данные, 2 Telegram — только для пути "пароль"; для телеграма степпер не показываем
  const animClass = dir === 1 ? "auth-step-forward" : "auth-step-back";

  return (
    <div className="relative min-h-[calc(100vh-64px)] flex items-center justify-center px-4 py-16">
      <AuthBackground />

      <div className="auth-card-rise max-w-md w-full">
        <div className="auth-glow-border rounded-card">
        <div className="card p-8 relative overflow-hidden z-[1]">
          <div
            className="absolute top-0 left-0 right-0 h-[2px] opacity-70"
            style={{ background: "linear-gradient(90deg, transparent, var(--color-accent), transparent)" }}
          />

          <div className="flex items-center gap-3 mb-1">
            {step > 0 && (
              <button
                type="button"
                onClick={goBack}
                className="shrink-0 w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/50 hover:text-white transition-colors"
              >
                <ChevronLeft size={16} />
              </button>
            )}
            <Sparkles size={20} className="text-accent shrink-0" />
            <h1
              className="text-2xl font-bold auth-title-sheen bg-clip-text text-transparent"
              style={{ backgroundImage: "linear-gradient(90deg, #fff, var(--color-accent-light), #fff)" }}
            >
              {t("auth_register_title")}
            </h1>
          </div>
          <p className="text-white/40 text-sm mb-5">{t("auth_register_subtitle")}</p>

          {/* Степпер с подписями — виден только на пути "пароль", у телеграм-пути своя внутренняя логика статусов */}
          {usesSteps && (
            <div className="flex items-center mb-7">
              {STEP_LABELS.map((label, i) => (
                <div key={label} className="flex items-center flex-1 last:flex-none">
                  <div className="flex flex-col items-center gap-1.5">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                        i < step
                          ? "bg-accent text-black"
                          : i === step
                          ? "bg-accent/15 text-accent ring-2 ring-accent"
                          : "bg-white/5 text-white/30"
                      }`}
                    >
                      {i < step ? <Check size={14} strokeWidth={3} /> : i + 1}
                    </div>
                    <span className={`text-[10px] font-medium ${i <= step ? "text-white/70" : "text-white/25"}`}>{label}</span>
                  </div>
                  {i < STEP_LABELS.length - 1 && (
                    <div className={`flex-1 h-px mx-2 mb-4 transition-colors duration-300 ${i < step ? "bg-accent" : "bg-white/10"}`} />
                  )}
                </div>
              ))}
            </div>
          )}

          <div key={`${mode}-${step}`} className={animClass}>
            {step === 0 && (
              <div className="space-y-6">
                <div>
                  <p className="text-xs text-white/40 mb-2">{t("auth_language_label")}</p>
                  <div className="flex gap-2">
                    {LANGUAGES.map((l) => (
                      <button
                        key={l.code}
                        type="button"
                        onClick={() => setLanguage(l.code)}
                        className={`flex-1 py-2 rounded-btn text-sm flex items-center justify-center gap-1.5 transition-all duration-200 ${
                          language === l.code ? "bg-accent text-black scale-[1.02]" : "bg-surface text-white/60 hover:bg-white/10"
                        }`}
                      >
                        <span>{l.flag}</span> {l.label}
                      </button>
                    ))}
                  </div>
                </div>

                {(flags.telegramRegisterEnabled || flags.telegramLoginEnabled) && (
                  <div className="space-y-3">
                    <p className="text-xs text-white/40">Быстрая регистрация через Telegram</p>
                    <TelegramLoginWidget
                      refCode={refCode}
                      onSuccess={() => {
                        celebrate("register");
                        router.push("/profile");
                      }}
                    />
                    <p className="text-[11px] text-white/30 text-center">
                      Один клик через официальный вход Telegram — без пароля и почты. Юзернейм выберешь после входа.
                    </p>
                    <div className="flex items-center gap-2 text-xs text-white/30">
                      <div className="h-px bg-white/10 flex-1" /> или другим способом <div className="h-px bg-white/10 flex-1" />
                    </div>
                  </div>
                )}

                {flags.telegramRegisterEnabled && (
                  <div>
                    <p className="text-xs text-white/40 mb-2">Способ регистрации</p>
                    <div className="relative flex bg-surface rounded-btn p-1">
                      <div
                        className="absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-btn bg-accent transition-transform duration-300 ease-out"
                        style={{ transform: mode === "password" ? "translateX(0)" : "translateX(calc(100% + 8px))" }}
                      />
                      <button
                        type="button"
                        onClick={() => setMode("password")}
                        className={`relative z-10 flex-1 py-2 rounded-btn text-sm font-medium transition-colors duration-200 ${
                          mode === "password" ? "text-black" : "text-white/60"
                        }`}
                      >
                        Email и пароль
                      </button>
                      <button
                        type="button"
                        onClick={() => setMode("telegram")}
                        className={`relative z-10 flex-1 py-2 rounded-btn text-sm font-medium flex items-center justify-center gap-1.5 transition-colors duration-200 ${
                          mode === "telegram" ? "text-black" : "text-white/60"
                        }`}
                      >
                        <MessageCircle size={14} /> Через Telegram
                      </button>
                    </div>
                  </div>
                )}

                <button type="button" onClick={goNext} className="btn-primary w-full py-3 hover:shadow-[0_0_24px_-4px_var(--color-accent)] transition-shadow">
                  Продолжить
                </button>
              </div>
            )}

            {step === 1 && mode === "password" && (
              <form onSubmit={handleSubmit} className="space-y-3.5">
                <div className="relative group">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors" size={18} />
                  <input
                    autoFocus
                    required
                    autoComplete="name"
                    enterKeyHint="next"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t("auth_name_placeholder")}
                    className="input-field pl-10 focus:ring-2 focus:ring-accent/30 transition-shadow"
                  />
                </div>

                <div>
                  <div className="relative group">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors text-sm">@</span>
                    <input
                      required
                      autoComplete="username"
                      autoCapitalize="none"
                      spellCheck={false}
                      maxLength={20}
                      value={username}
                      onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))}
                      placeholder="Юзернейм (латиница, цифры, _)"
                      className="input-field pl-9 focus:ring-2 focus:ring-accent/30 transition-shadow"
                    />
                  </div>
                  <p className="text-[11px] text-white/30 mt-1 ml-1">3-20 символов. Это ссылка на твой профиль — обязателен.</p>
                </div>

                <div>
                  <div className="relative group">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors" size={18} />
                    <input
                      type="email"
                      required
                      autoComplete="email"
                      enterKeyHint="next"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      onBlur={() => setEmailTouched(true)}
                      placeholder={t("auth_email_placeholder")}
                      className={`input-field pl-10 pr-10 focus:ring-2 transition-shadow ${
                        emailTouched && email && !EMAIL_RE.test(email.trim()) ? "border-red-400/60 focus:ring-red-400/20" : "focus:ring-accent/30"
                      }`}
                    />
                    {EMAIL_RE.test(email.trim()) && <Check size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-green-400" />}
                  </div>
                  {emailTouched && email && !EMAIL_RE.test(email.trim()) && (
                    <p className="text-[11px] text-red-400/80 mt-1 ml-1">Проверь адрес — похоже, в нём ошибка</p>
                  )}
                </div>

                <div>
                  <div className="relative group">
                    <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors" size={18} />
                    <input
                      required
                      type="number"
                      inputMode="numeric"
                      min={MIN_AGE}
                      max={MAX_AGE}
                      enterKeyHint="next"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      placeholder="Возраст"
                      className="input-field pl-10 focus:ring-2 focus:ring-accent/30 transition-shadow"
                    />
                  </div>
                  <p className="text-[11px] text-white/25 mt-1 ml-1">Видно только администрации, нигде на сайте не показывается.</p>
                </div>

                <div>
                  <div className="relative group">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors" size={18} />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      autoComplete="new-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={t("auth_password_placeholder")}
                      className="input-field pl-10 pr-11 focus:ring-2 focus:ring-accent/30 transition-shadow"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70 transition-colors"
                      aria-label={showPassword ? "Скрыть пароль" : "Показать пароль"}
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                    </button>
                  </div>
                  {password && (
                    <div className="mt-2">
                      <div className="flex gap-1">
                        {[1, 2, 3, 4].map((n) => (
                          <div
                            key={n}
                            className="h-1 flex-1 rounded-full transition-colors duration-300"
                            style={{ background: n <= pwStrength.score ? pwStrength.color : "rgba(255,255,255,0.08)" }}
                          />
                        ))}
                      </div>
                      <p className="text-[11px] mt-1 ml-0.5" style={{ color: pwStrength.color }}>
                        {pwStrength.label}
                      </p>
                    </div>
                  )}
                </div>

                <label className="flex items-start gap-2.5 text-xs text-white/50 pt-1 cursor-pointer">
                  <input type="checkbox" required checked={agreed} onChange={(e) => setAgreed(e.target.checked)} className="mt-0.5 accent-[#ff9800]" />
                  <span>
                    Я согласен с{" "}
                    <Link href="/rules" target="_blank" className="text-accent hover:underline">
                      правилами платформы
                    </Link>
                    ,{" "}
                    <Link href="/privacy" target="_blank" className="text-accent hover:underline">
                      политикой конфиденциальности
                    </Link>{" "}
                    и{" "}
                    <Link href="/terms" target="_blank" className="text-accent hover:underline">
                      пользовательским соглашением
                    </Link>
                    .
                  </span>
                </label>

                <button
                  disabled={loading || !agreed}
                  className="btn-primary w-full py-3 disabled:opacity-50 hover:shadow-[0_0_24px_-4px_var(--color-accent)] transition-shadow"
                >
                  {loading ? "Готовим Telegram..." : "Далее — подтвердить в Telegram"}
                </button>
              </form>
            )}

            {step === 2 && mode === "password" && (
              <div className="space-y-5">
                <p className="text-sm text-white/55 text-center">
                  Подтверди регистрацию через Telegram-бота — код придёт туда, а не на почту.
                </p>

                <ol className="space-y-2.5">
                  {[
                    { n: 1, text: "Открой бота по кнопке ниже", done: !!tgvUrl && tgvSent },
                    { n: 2, text: "Нажми «Start» — бот пришлёт код", done: tgvSent },
                    { n: 3, text: "Введи 6 цифр кода здесь", done: false },
                  ].map((row) => (
                    <li key={row.n} className="flex items-center gap-3 text-sm">
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold shrink-0 transition-colors ${
                          row.done ? "bg-green-500/20 text-green-400" : "bg-white/5 text-white/40"
                        }`}
                      >
                        {row.done ? <Check size={13} strokeWidth={3} /> : row.n}
                      </span>
                      <span className={row.done ? "text-white/40 line-through decoration-white/20" : "text-white/70"}>{row.text}</span>
                    </li>
                  ))}
                </ol>

                {tgvUrl && (
                  <a
                    href={tgvUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary w-full py-3 text-sm flex items-center justify-center gap-2 hover:shadow-[0_0_24px_-4px_var(--color-accent)] transition-shadow"
                  >
                    <MessageCircle size={16} /> Открыть Telegram-бота <ExternalLink size={14} />
                  </a>
                )}

                {!tgvSent ? (
                  <div className="flex items-center justify-center gap-2 text-xs text-white/40">
                    <span className="w-2 h-2 rounded-full bg-accent animate-pulse" /> Ждём, пока ты нажмёшь «Start»...
                  </div>
                ) : (
                  <form onSubmit={handleConfirmTelegramCode} className="space-y-3">
                    <p className="text-xs text-green-400 text-center">Код отправлен в Telegram — введи его ниже</p>
                    <input
                      autoFocus
                      required
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      maxLength={6}
                      value={tgvCode}
                      onChange={(e) => setTgvCode(e.target.value.replace(/\D/g, ""))}
                      placeholder="• • • • • •"
                      className="input-field text-center text-xl tracking-[10px] font-mono focus:ring-2 focus:ring-accent/30 transition-shadow"
                    />
                    <button
                      disabled={loading || tgvCode.length !== 6}
                      className="btn-primary w-full py-3 disabled:opacity-50 hover:shadow-[0_0_24px_-4px_var(--color-accent)] transition-shadow"
                    >
                      {loading ? t("auth_submit_creating") : t("auth_submit_register")}
                    </button>
                  </form>
                )}
              </div>
            )}

            {step >= 1 && mode === "telegram" && (
              <>
                {tgConfirmed ? (
                  <div className="text-center py-4 space-y-4">
                    <CheckCircle2 className="mx-auto text-green-400" size={36} />
                    <p className="text-sm text-white/70">
                      Аккаунт создан! Код для входа уже отправлен тебе в Telegram — введи его на странице входа.
                    </p>
                    <Link href="/auth/login" className="btn-primary inline-block px-6 py-3 text-sm">
                      Перейти ко входу
                    </Link>
                  </div>
                ) : tgLinkUrl ? (
                  <div className="space-y-3 text-center py-2">
                    <div className="relative w-14 h-14 mx-auto">
                      <div className="absolute inset-0 rounded-full border-2 border-accent/20 border-t-accent auth-spin-slow" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <MessageCircle size={22} className="text-accent" />
                      </div>
                    </div>
                    <a
                      href={tgLinkUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-primary px-6 py-3 text-sm inline-flex items-center gap-2 hover:shadow-[0_0_24px_-4px_var(--color-accent)] transition-shadow"
                    >
                      Открыть Telegram-бота <ExternalLink size={14} />
                    </a>
                    <p className="text-xs text-white/40">
                      Нажми «Start» в боте — аккаунт создастся автоматически, и мы пришлём код для входа прямо туда.
                      Эта страница обновится сама.
                    </p>
                    <div className="flex items-center justify-center gap-2 text-xs text-white/30 pt-2">
                      <span className="w-2 h-2 rounded-full bg-accent animate-pulse" /> Ждём подтверждения...
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleStartTelegramRegister} className="space-y-4">
                    <div className="relative group">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors" size={18} />
                      <input
                        autoFocus
                        required
                        autoComplete="name"
                        value={tgName}
                        onChange={(e) => setTgName(e.target.value)}
                        placeholder="Имя пользователя"
                        className="input-field pl-10 focus:ring-2 focus:ring-accent/30 transition-shadow"
                      />
                    </div>
                  <div>
                    <div className="relative group">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors text-sm">@</span>
                      <input
                        required
                        autoComplete="username"
                        autoCapitalize="none"
                        spellCheck={false}
                        maxLength={20}
                        value={tgUsername}
                        onChange={(e) => setTgUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))}
                        placeholder="Юзернейм (латиница, цифры, _)"
                        className="input-field pl-9 focus:ring-2 focus:ring-accent/30 transition-shadow"
                      />
                    </div>
                    <p className="text-[11px] text-white/30 mt-1 ml-1">3-20 символов. Это ссылка на твой профиль — обязателен.</p>
                  </div>

                    <div className="relative group">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors" size={18} />
                      <input
                        type="email"
                        required
                        autoComplete="email"
                        value={tgEmail}
                        onChange={(e) => setTgEmail(e.target.value)}
                        placeholder="Email"
                        className="input-field pl-10 focus:ring-2 focus:ring-accent/30 transition-shadow"
                      />
                    </div>
                    <div className="relative group">
                      <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-accent transition-colors" size={18} />
                      <input
                        type="number"
                        required
                        min={MIN_AGE}
                        max={MAX_AGE}
                        value={tgAge}
                        onChange={(e) => setTgAge(e.target.value)}
                        placeholder="Возраст"
                        className="input-field pl-10 focus:ring-2 focus:ring-accent/30 transition-shadow"
                      />
                    </div>
                    <button
                      disabled={tgCreating}
                      className="btn-primary w-full py-3 disabled:opacity-50 hover:shadow-[0_0_24px_-4px_var(--color-accent)] transition-shadow"
                    >
                      {tgCreating ? "Готовим ссылку..." : "Продолжить в Telegram"}
                    </button>
                    <p className="text-xs text-white/30 text-center">Без пароля — вход будет по коду из Telegram.</p>
                  </form>
                )}
              </>
            )}
          </div>

          <p className="text-center text-sm text-white/40 mt-6">
            {t("auth_have_account")}{" "}
            <Link href="/auth/login" className="text-accent hover:underline">
              {t("auth_login_link")}
            </Link>
          </p>
        </div>
        </div>
      </div>
    </div>
  );
}

export default function RegisterPage() {
  return (
    <Suspense
      fallback={
        <div className="relative min-h-[calc(100vh-64px)] flex items-center justify-center px-4">
          <AuthBackground />
          <p className="text-white/40">Загрузка...</p>
        </div>
      }
    >
      <RegisterInner />
    </Suspense>
  );
}
