"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Image from "next/image";
import { Star, ShieldCheck, MessageCircle } from "lucide-react";
import { getUidByUsername } from "@/lib/usernames";
import { getPublicProfileCached, PublicProfile } from "@/lib/sellerCache";
import { getSellerReviews } from "@/lib/reviews";
import { getProducts } from "@/lib/products";
import { Review, Product, BADGE_COLOR, BADGE_LABEL, CHECKMARK_BADGES } from "@/types";
import { ProductCard } from "@/components/ProductCard";
import { StyledNickname } from "@/components/StyledNickname";
import { ProfileBanner } from "@/components/ProfileBanner";
import { safeImageSrc } from "@/lib/safeImage";
import { useAuth } from "@/lib/authContext";

export default function SellerProfilePage() {
  const { username } = useParams<{ username: string }>();
  const { user } = useAuth();
  const router = useRouter();
  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [notFound, setNotFound] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const uid = await getUidByUsername(username);
      if (!uid) {
        setNotFound(true);
        setLoading(false);
        return;
      }
      const [p, r, prod] = await Promise.all([getPublicProfileCached(uid), getSellerReviews(uid), getProducts({ sellerId: uid, excludeWheelLocked: true })]);
      setProfile(p);
      setReviews(r);
      setProducts(prod);
      setLoading(false);
    }
    load().catch(() => {
      setNotFound(true);
      setLoading(false);
    });
  }, [username]);

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-20 text-center text-white/40">Загрузка...</div>;
  if (notFound || !profile) return <div className="max-w-4xl mx-auto px-4 py-20 text-center text-white/40">Продавец не найден.</div>;

  const avgRating = profile.ratingCount ? (profile.ratingSum ?? 0) / profile.ratingCount : null;
  const checkmarks = profile.badges.filter((b) => CHECKMARK_BADGES.includes(b));
  const otherBadges = profile.badges.filter((b) => !CHECKMARK_BADGES.includes(b));

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="card overflow-hidden">
      <ProfileBanner url={profile.bannerURL} className="h-28 sm:h-40" />
      <div className="p-6 pt-0 -mt-10 flex items-start gap-5">
        <div className="relative w-24 h-24 rounded-full overflow-hidden bg-surface shrink-0 ring-4 ring-surface shadow-[0_0_0_2px_var(--color-accent)]">
          <Image src={safeImageSrc(profile.photoURL, "/placeholder.svg")} alt={profile.displayName} fill className="object-cover" sizes="96px" />
          {profile.isOnline && (
            <span className="absolute bottom-1 right-1 w-3.5 h-3.5 rounded-full bg-green-400 border-2 border-surface" />
          )}
        </div>
        <div className="flex-1 min-w-0 pt-11">
          <div className="flex items-center gap-1.5 flex-wrap">
            <h1 className="text-xl font-bold"><StyledNickname name={profile.displayName} nameColor={profile.nameColor} nameFont={profile.nameFont} /></h1>
            {checkmarks.map((b) => (
              <ShieldCheck key={b} size={18} style={{ color: BADGE_COLOR[b] }} aria-label={BADGE_LABEL[b]} />
            ))}
          </div>
          <p className="text-white/40 text-sm mb-2">
            @{profile.username} · {profile.isOnline ? <span className="text-green-400">в сети</span> : "не в сети"}
          </p>
          {profile.bio && <p className="text-white/60 text-sm mb-2">{profile.bio}</p>}
          <div className="flex items-center gap-3 flex-wrap">
            {avgRating !== null && (
              <span className="flex items-center gap-1 text-sm text-accent font-medium">
                <Star size={14} className="fill-accent" /> {avgRating.toFixed(1)} ({profile.ratingCount})
              </span>
            )}
            {user && user.uid !== profile.uid && (
              <button
                onClick={() =>
                  router.push(
                    `/chats?dm=${profile.uid}&name=${encodeURIComponent(profile.displayName)}&photo=${encodeURIComponent(profile.photoURL ?? "")}`
                  )
                }
                className="btn-secondary px-3 py-1.5 text-xs flex items-center gap-1.5"
              >
                <MessageCircle size={13} /> Написать
              </button>
            )}
            <div className="flex flex-wrap gap-1">
              {otherBadges.map((b) => (
                <span
                  key={b}
                  className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                  style={{ background: `${BADGE_COLOR[b]}22`, color: BADGE_COLOR[b] }}
                >
                  {BADGE_LABEL[b]}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
      </div>

      <div>
        <h2 className="text-lg font-bold mb-3">Товары продавца ({products.length})</h2>
        {products.length === 0 ? (
          <div className="card p-8 text-center text-white/40">У продавца пока нет товаров в каталоге.</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="text-lg font-bold mb-3">Отзывы ({reviews.length})</h2>
        {reviews.length === 0 ? (
          <div className="card p-8 text-center text-white/40">Отзывов пока нет.</div>
        ) : (
          <div className="space-y-2">
            {reviews.map((r) => (
              <div key={r.id} className="card p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="font-medium text-sm">{r.buyerName}</p>
                  <div className="flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} size={12} className={i < r.rating ? "text-accent fill-accent" : "text-white/15"} />
                    ))}
                  </div>
                </div>
                <p className="text-xs text-white/40 mb-1">{r.productName}</p>
                {r.text && <p className="text-sm text-white/70">{r.text}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
